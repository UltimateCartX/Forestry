package com.example.forestry.data.models

sealed class GNSSState {
    data object Disconnected: GNSSState()
    data object Invalid : GNSSState() // The connected device is not a GNSS receptor
    data object Connected : GNSSState()
}