package com.example.forestry.utils

import android.content.Context
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import androidx.core.content.ContextCompat
import androidx.core.graphics.scale
import androidx.core.graphics.drawable.toDrawable

fun scaledDrawable(context: Context, resId: Int, sizeDp: Int): Drawable {
    val drawable = ContextCompat.getDrawable(context, resId)!!
    val bitmap = (drawable as BitmapDrawable).bitmap

    val sizePx = (sizeDp * context.resources.displayMetrics.density).toInt()

    val scaledBitmap = bitmap.scale(sizePx, sizePx)
    return scaledBitmap.toDrawable(context.resources)
}