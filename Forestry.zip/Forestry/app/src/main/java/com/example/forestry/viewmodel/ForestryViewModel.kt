package com.example.forestry.viewmodel

import android.bluetooth.BluetoothDevice
import android.content.Context
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.forestry.data.models.BluetoothConnectionState
import com.example.forestry.data.models.LoginRequest
import com.example.forestry.data.models.Project
import com.example.forestry.data.models.ThemeMode
import com.example.forestry.data.models.TokenResponse
import com.example.forestry.data.models.Tree
import com.example.forestry.data.models.User
import com.example.forestry.data.repositories.APIRepository
import com.example.forestry.data.repositories.DataStoreRepository
import com.example.forestry.data.repositories.GNSSRepository
import com.example.forestry.ui.navigation.NavEvent
import com.example.forestry.ui.navigation.Screen
import com.example.forestry.ui.previews.APIRepositoryLike
import com.example.forestry.ui.previews.DataStoreRepositoryLike
import com.example.forestry.ui.previews.GNSSRepositoryLike
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.osmdroid.util.GeoPoint
import java.util.UUID

/**
    The main ViewModel of the application

    Handles communication between the UI layer and the data layer
 */
open class ForestryViewModel(context: Context? = null): ViewModel() {

    private val apiRepository = when (context) {
        is Context -> APIRepository(context)
        else -> object : APIRepositoryLike {
            override suspend fun login(login: LoginRequest): TokenResponse { return TokenResponse("") }
            override suspend fun getMe(token: String): User { return User("", "John", "Doe", "john.doe@example.com", "Standard") }
            override suspend fun getTrees(token: String): List<Tree> { return emptyList() }
            override suspend fun getProjects(token: String): List<Project> { return emptyList() }
            override suspend fun addProject(token: String, project: Project) {}
        }
    }

    private val dataStoreRepository : DataStoreRepositoryLike = when (context) {
        is Context -> DataStoreRepository(context)
        else -> object : DataStoreRepositoryLike {
            override val themeMode: Flow<ThemeMode> = flow { emit(ThemeMode.SYSTEM) }
            override suspend fun setTheme(mode: ThemeMode) {}
        }
    }

    private val gnssRepository : GNSSRepositoryLike = when (context) {
        is Context -> GNSSRepository(context)
        else -> object : GNSSRepositoryLike {
            override val connectionState: StateFlow<BluetoothConnectionState> = MutableStateFlow<BluetoothConnectionState>(BluetoothConnectionState.Disconnected).asStateFlow()
            override val incomingData: StateFlow<String?> = MutableStateFlow<String?>(null).asStateFlow()
            override fun getBondedDevices(): List<BluetoothDevice> { return emptyList() }
            override fun connect(device: BluetoothDevice) {}
            override fun disconnect() {}
        }
    }

    // Preferences

    val themeMode = dataStoreRepository.themeMode.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ThemeMode.SYSTEM)

    fun setTheme(mode: ThemeMode) {
        viewModelScope.launch {
            dataStoreRepository.setTheme(mode)
        }
    }

    // Navigation

    private val _navEvents = MutableSharedFlow<NavEvent>()
    val navEvents = _navEvents.asSharedFlow()

    fun navigateTo(screen: Screen, popBackStack: Boolean = false) {
        viewModelScope.launch {
            _navEvents.emit(NavEvent.Navigate(screen.route, popBackStack))
        }
    }

    fun navigateBack() {
        viewModelScope.launch {
            _navEvents.emit(NavEvent.NavigateBack)
        }
    }

    // Login

    private val _isConnected = MutableStateFlow(false)
    val isConnected: StateFlow<Boolean> = _isConnected

    private val _emailText = MutableStateFlow("")
    val emailText: StateFlow<String> = _emailText

    fun onEmailTextChange(newText: String) {
        _emailText.value = newText
    }

    private val _passwordText = MutableStateFlow("")
    val passwordText: StateFlow<String> = _passwordText

    fun onPasswordTextChange(newText: String) {
        _passwordText.value = newText
    }

    private val _token = MutableStateFlow("")
    val token: StateFlow<String> = _token

    private val _online = MutableStateFlow(false)
    val online: StateFlow<Boolean> = _online

    fun testAPI() {
        viewModelScope.launch {
            try {
                apiRepository.login(LoginRequest("a", "a"))
                _online.value = true
            } catch (e: Exception) {
                e.message?.let { Log.e("Forestry", it) }
                _online.value = false
            }
        }
    }

    fun login() {
        viewModelScope.launch {
            try {
                val response = apiRepository.login(LoginRequest(_emailText.value, _passwordText.value))
                Log.d("Forestry", response.toString())
                _token.value = response.access_token
                _isConnected.value = true
                getMe()
                getTrees()
                navigateTo(Screen.MAP, true)
            } catch (e: Exception) {
                e.message?.let { Log.e("Forestry", it) }
            }
        }
    }

    fun logoff() {
        _token.value = ""
        _isConnected.value = false
    }

    fun getMe() {
        viewModelScope.launch {
            try {
                val response = apiRepository.getMe("Bearer " + _token.value)
                Log.d("Forestry", response.toString())
            } catch (e: Exception) {
                e.message?.let { Log.e("Forestry", it) }
            }
        }
    }

    private val _treeList = MutableStateFlow<List<Tree>>(emptyList())
    val treeList: StateFlow<List<Tree>> = _treeList

    fun getTrees() {
        viewModelScope.launch {
            try {
                val response = apiRepository.getTrees("Bearer " + _token.value)
                Log.d("Forestry", response.toString())
                _treeList.value = response
            } catch (e: Exception) {
                e.message?.let { Log.e("Forestry", it) }
            }
        }
    }

    var projects by mutableStateOf<List<Project>>(emptyList())
        private set

    fun loadProjects() {
        viewModelScope.launch {
            projects = apiRepository.getProjects("Bearer " + _token.value)
        }
    }

    fun addProject(project: Project) {
        viewModelScope.launch {
            apiRepository.addProject("Bearer " + _token.value, project)
        }
        loadProjects()
    }

    private val _projectCreationMode = MutableStateFlow<Boolean>(false)
    val projectCreationMode: StateFlow<Boolean> = _projectCreationMode

    // GNSS

    open val gnssConnectionState: StateFlow<BluetoothConnectionState> = gnssRepository.connectionState

    private val _gnssLat = MutableStateFlow<Double?>(null)
    val gnssLat: StateFlow<Double?> = _gnssLat

    private val _gnssLon = MutableStateFlow<Double?>(null)
    val gnssLon: StateFlow<Double?> = _gnssLon

    fun getGnssPos(): GeoPoint? {
        return if (_gnssLat.value !== null && _gnssLon.value !== null) {
            GeoPoint(_gnssLat.value!!, _gnssLon.value!!)
        } else {
            null
        }
    }

    fun setGnssPos(lat: Double, lon: Double) {
        _gnssLat.value = lat
        _gnssLon.value = lon
    }

    fun getBondedDevices(): List<BluetoothDevice> {
        return gnssRepository.getBondedDevices()
    }

    val incomingData: StateFlow<String?> = gnssRepository.incomingData

    fun connect(device: BluetoothDevice) {
        gnssRepository.connect(device)
    }

    fun disconnect() {
        gnssRepository.disconnect()
    }

    override fun onCleared() {
        gnssRepository.disconnect()
    }

    // Project

    private val _currentProject = MutableStateFlow<Project?>(null)
    val currentProject: StateFlow<Project?> = _currentProject

    fun setCurrentProject(project: Project) {
        _currentProject.value = project
    }

    private val _projectCreationName = MutableStateFlow("")
    val projectCreationName: StateFlow<String> = _projectCreationName

    fun onProjectCreationNameChange(newText: String) {
        _projectCreationName.value = newText
    }

    private val _projectDelimiterPoints = MutableStateFlow(mutableListOf<GeoPoint>())
    val projectDelimiterPoints: StateFlow<MutableList<GeoPoint>> = _projectDelimiterPoints

    fun openProjectDelimiter() {
        _projectCreationMode.value = true
        navigateTo(Screen.MAP)
    }

    fun closeProjectDelimiter() {
        _projectCreationMode.value = false
        val newProject = Project(UUID.randomUUID(), _projectCreationName.value, _projectDelimiterPoints.value.toList())
        addProject(newProject)
        setCurrentProject(newProject)
        _projectCreationName.value = ""
        _projectDelimiterPoints.value.clear()
        navigateTo(Screen.CONFIGURATION)
    }
}