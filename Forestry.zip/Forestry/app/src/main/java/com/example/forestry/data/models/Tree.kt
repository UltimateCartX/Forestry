package com.example.forestry.data.models

data class Tree(
    val id: String,
    val latitude: Double,
    val longitude: Double,
    val essence: String,
    val diameter: Long,
    val height: Long,
    val cclass: String,
    val state: String
)
